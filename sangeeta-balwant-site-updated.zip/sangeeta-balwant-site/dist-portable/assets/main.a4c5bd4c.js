(function () {
'use strict';
var doc = document, root = doc.documentElement;
var $ = function (s, c) { return (c || doc).querySelector(s); };
var $$ = function (s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); };
root.classList.add('js');
var ATTRS = ['placeholder', 'alt', 'aria-label', 'title', 'content'];
function lang() { return root.dataset.lang === 'en' ? 'en' : 'hi'; }
function applyLang(l) {
root.dataset.lang = l; root.lang = l;
var t = root.getAttribute('data-title-' + l); if (t) doc.title = t;
ATTRS.forEach(function (a) {
$$('[data-' + l + '-' + a + ']').forEach(function (el) { el.setAttribute(a, el.getAttribute('data-' + l + '-' + a)); });
});
$$('.js-wa').forEach(buildWa);
$$('.lang-switch').forEach(function (b) { b.setAttribute('aria-pressed', l === 'en' ? 'true' : 'false'); });
$$('[data-date]').forEach(fmtDate);
var f = $('form.contact'); if (f) clearErrors(f);
}
function setLang(l) { try { localStorage.setItem('lang', l); } catch (e) {} applyLang(l); }
$$('.lang-switch').forEach(function (b) {
b.addEventListener('click', function () { setLang(lang() === 'en' ? 'hi' : 'en'); });
});
function fmtDate(el) {
var d = new Date(el.getAttribute('data-date') + 'T00:00:00');
if (isNaN(d)) return;
try { el.textContent = d.toLocaleDateString(lang() === 'hi' ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) {}
}
function buildWa(a) {
var num = (a.getAttribute('data-number') || '').replace(/\D/g, '');
var txt = a.getAttribute('data-wa-' + lang()) || '';
a.href = 'https://wa.me/' + num + '?text=' + encodeURIComponent(txt);
}
var header = $('.site-header');
var burger = $('.burger');
function onScroll() {
if (header) header.classList.toggle('scrolled', window.scrollY > 8);
var tt = $('.to-top'); if (tt) tt.classList.toggle('show', window.scrollY > 700);
}
window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
if (burger) {
burger.addEventListener('click', function () {
var open = header.classList.toggle('nav-open');
burger.setAttribute('aria-expanded', open ? 'true' : 'false');
});
$$('.nav a').forEach(function (a) { a.addEventListener('click', function () { header.classList.remove('nav-open'); burger.setAttribute('aria-expanded', 'false'); }); });
}
var tt = $('.to-top'); if (tt) tt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
var rev = $$('.reveal');
if ('IntersectionObserver' in window) {
var io = new IntersectionObserver(function (es) {
es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
}, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
rev.forEach(function (el) { io.observe(el); });
} else { rev.forEach(function (el) { el.classList.add('in'); }); }
$$('[data-filter-group]').forEach(function (group) {
var target = $(group.getAttribute('data-filter-group'));
if (!target) return;
var items = $$('[data-cat]', target);
var empty = target.parentNode.querySelector('.filter-empty');
$$('.filter', group).forEach(function (btn) {
btn.addEventListener('click', function () {
$$('.filter', group).forEach(function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
var cat = btn.getAttribute('data-value'), shown = 0;
items.forEach(function (it) {
var ok = cat === 'all' || it.getAttribute('data-cat') === cat;
it.hidden = !ok; if (ok) shown++;
});
if (empty) empty.hidden = shown !== 0;
if (target.classList.contains('photos')) buildLightboxList();
});
});
});
var lb = $('.lightbox'), list = [], idx = 0, lastFocus = null;
function buildLightboxList() { list = $$('.g-item').filter(function (b) { return !b.hidden; }); }
function show(i) {
if (!list.length) return;
idx = (i + list.length) % list.length;
var b = list[idx], img = $('img', lb), cap = $('figcaption', lb);
img.src = b.getAttribute('data-full'); img.alt = b.getAttribute('data-alt-' + lang()) || '';
cap.innerHTML = $('.capsrc', b).innerHTML;
}
function openLb(i) { lastFocus = doc.activeElement; buildLightboxList(); show(i); lb.classList.add('open'); doc.body.style.overflow = 'hidden'; $('.lb-close', lb).focus(); }
function closeLb() { lb.classList.remove('open'); doc.body.style.overflow = ''; if (lastFocus) lastFocus.focus(); }
if (lb) {
buildLightboxList();
$$('.g-item').forEach(function (b) { b.addEventListener('click', function () { buildLightboxList(); openLb(list.indexOf(b)); }); });
$('.lb-close', lb).addEventListener('click', closeLb);
$('.lb-prev', lb).addEventListener('click', function () { show(idx - 1); });
$('.lb-next', lb).addEventListener('click', function () { show(idx + 1); });
lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); });
doc.addEventListener('keydown', function (e) {
if (!lb.classList.contains('open')) return;
if (e.key === 'Escape') closeLb();
if (e.key === 'ArrowLeft') show(idx - 1);
if (e.key === 'ArrowRight') show(idx + 1);
});
var sx = null;
lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
lb.addEventListener('touchend', function (e) {
if (sx === null) return; var dx = e.changedTouches[0].clientX - sx;
if (Math.abs(dx) > 50) show(idx + (dx < 0 ? 1 : -1)); sx = null;
});
}
$$('.playbtn[data-yt]').forEach(function (b) {
b.addEventListener('click', function () {
var f = doc.createElement('iframe');
f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(b.getAttribute('data-yt')) + '?autoplay=1&rel=0';
f.allow = 'autoplay; encrypted-media; picture-in-picture'; f.allowFullscreen = true; f.title = b.getAttribute('aria-label') || 'Video';
b.parentNode.replaceChild(f, b); f.focus();
});
});
$$('[data-share]').forEach(function (el) {
var kind = el.getAttribute('data-share'), url = encodeURIComponent(location.href.split('#')[0]);
var title = encodeURIComponent(doc.title);
if (kind === 'wa') el.href = 'https://wa.me/?text=' + title + '%20' + url;
if (kind === 'x') el.href = 'https://twitter.com/intent/tweet?text=' + title + '&url=' + url;
if (kind === 'fb') el.href = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
if (kind === 'copy') el.addEventListener('click', function () {
var done = function () { var o = el.innerHTML; el.textContent = el.getAttribute('data-' + lang() + '-done'); setTimeout(function () { el.innerHTML = o; }, 1800); };
if (navigator.clipboard) navigator.clipboard.writeText(location.href).then(done); else done();
});
});
var MSG = {
en: { req: 'This field is required.', email: 'Enter a valid email address.', phone: 'Enter a valid 10-digit Indian mobile number.', min: 'Please write at least 10 characters.', ok: 'Thank you. Your message has been sent. The office will get back to you.', fail: 'Sorry, the message could not be sent. Please try again or use WhatsApp / email.' },
hi: { req: 'यह स्थान भरना आवश्यक है।', email: 'कृपया सही ईमेल पता लिखें।', phone: 'कृपया सही 10 अंकों का भारतीय मोबाइल नंबर लिखें।', min: 'कृपया कम से कम 10 अक्षर लिखें।', ok: 'धन्यवाद। आपका संदेश भेज दिया गया है। कार्यालय आपसे संपर्क करेगा।', fail: 'क्षमा करें, संदेश नहीं भेजा जा सका। कृपया पुनः प्रयास करें या व्हाट्सऐप / ईमेल का उपयोग करें।' }
};
function setErr(field, key) {
var w = field.closest('.field'), e = $('.err', w);
if (key) { w.classList.add('invalid'); e.textContent = MSG[lang()][key]; field.setAttribute('aria-invalid', 'true'); }
else { w.classList.remove('invalid'); e.textContent = ''; field.removeAttribute('aria-invalid'); }
}
function clearErrors(f) { $$('.field', f).forEach(function (w) { w.classList.remove('invalid'); $('.err', w).textContent = ''; }); var m = $('.form-msg', f); if (m) m.className = 'form-msg'; }
function validate(f) {
var ok = true, v = function (n) { return f.elements[n].value.trim(); };
function check(name, fn) { var k = fn(v(name)); setErr(f.elements[name], k); if (k) ok = false; }
check('name', function (x) { return x ? '' : 'req'; });
check('subject', function (x) { return x ? '' : 'req'; });
check('message', function (x) { return !x ? 'req' : x.length < 10 ? 'min' : ''; });
check('phone', function (x) { return !x || /^(\+?91)?[6-9]\d{9}$/.test(x.replace(/[\s-]/g, '')) ? '' : 'phone'; });
check('email', function (x) { return !x || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(x) ? '' : 'email'; });
if (!v('phone') && !v('email')) {
var k = f.getAttribute('data-need-' + lang());
setErr(f.elements.phone, null); f.elements.phone.closest('.field').classList.add('invalid'); $('.err', f.elements.phone.closest('.field')).textContent = k; ok = false;
}
return ok;
}
var form = $('form.contact');
if (form) {
$$('input, select, textarea', form).forEach(function (el) { el.addEventListener('blur', function () { if (el.value) validate(form); }); });
form.addEventListener('submit', function (e) {
e.preventDefault();
var msg = $('.form-msg', form), btn = $('button[type=submit]', form);
msg.className = 'form-msg';
if (!validate(form)) { var bad = $('.field.invalid input, .field.invalid select, .field.invalid textarea', form); if (bad) bad.focus(); return; }
if (form.elements['bot-field'] && form.elements['bot-field'].value) return;
var data = new FormData(form), endpoint = form.getAttribute('data-endpoint');
btn.disabled = true; var label = btn.innerHTML; btn.textContent = btn.getAttribute('data-' + lang() + '-sending');
var req = endpoint
? fetch(endpoint, { method: 'POST', body: data, headers: { Accept: 'application/json' } })
: fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(data).toString() });
req.then(function (r) {
if (!r.ok) throw new Error(r.status);
form.reset(); msg.textContent = MSG[lang()].ok; msg.className = 'form-msg ok';
}).catch(function () { msg.textContent = MSG[lang()].fail; msg.className = 'form-msg fail'; })
.then(function () { btn.disabled = false; btn.innerHTML = label; msg.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); });
});
}
applyLang(lang());
})();