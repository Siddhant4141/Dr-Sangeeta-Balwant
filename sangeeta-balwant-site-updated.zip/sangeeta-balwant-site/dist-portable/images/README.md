# Image & media structure

| Folder / file | Purpose | Recommended size |
|---|---|---|
| `portrait.jpg` | Hero banner portrait (professional photo) | 800×1000 px (4:5), JPG, < 300 KB |
| `portrait-2.jpg` | About-section portrait | 800×1000 px (4:5) |
| `og-image.jpg` | Preview shown when links are shared on WhatsApp/Facebook/X | 1200×630 px |
| `news-default.jpg` | Fallback for news items without a photo | 1200×750 px |
| `news/` | Photos for news articles → reference as `/images/news/<file>.jpg` | 1200×750 px |
| `gallery/` | Event photographs → reference as `/images/gallery/<file>.jpg` | 1600×1200 px, < 400 KB |
| `sample/` | Demo placeholders used only by the preview build. Safe to delete. | – |

Replace the placeholder `portrait*.jpg` and `og-image.jpg` with real photographs (same file names). Compress photos first (squoosh.app). Use only photographs the office owns or is licensed to publish.
